function getRegisterUser() {
  return {
    firstName: 'Nitin',
    lastName: 'Luthra',
    email: `nitin.luthra${Date.now()}@pst.com`, // unique email
    password: '!StrongPass123!',
    dob: '1990-01-01',
    street: '123 Marsden',
    postalCode: '2000',
    city: 'Sydney',
    state: 'NSW',
    phone: '0412345678',
    country: 'AU', // match dropdown option value
  };
}

function getValidUser() {
  // If you want to test login with an existing user
  return {
    email: 'existing.user@pst.com',
    password: 'Password123!',
  };
}

module.exports = { getRegisterUser, getValidUser };
