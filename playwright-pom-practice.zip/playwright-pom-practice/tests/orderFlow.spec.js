import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductPage } from '../pages/ProductPage';
import { CartPage } from '../pages/CartPage';
import { CheckoutPage } from '../pages/CheckoutPage';
import { getValidUser } from '../data/userFactory';

test('Complete order flow', async ({ page }) => {
  const user = getValidUser();
  const loginPage = new LoginPage(page);
  const productPage = new ProductPage(page);
  const cartPage = new CartPage(page);
  const checkoutPage = new CheckoutPage(page);

  await loginPage.goto();
  await loginPage.login(user.email, user.password);

  await productPage.addPliersToCart();
  await productPage.gotoCheckout();


  await cartPage.checkout();
  await checkoutPage.fillShippingDetails(user);
  await checkoutPage.submitOrder();

  await expect(checkoutPage.successMessage).toContainText('Thank you');
});