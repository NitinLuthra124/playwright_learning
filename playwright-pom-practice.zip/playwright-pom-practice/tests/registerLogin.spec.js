import { test, expect } from '@playwright/test';
import { RegisterPage } from '../pages/RegisterPage';
import { LoginPage } from '../pages/LoginPage';
import { getRegisterUser } from '../data/userFactory';

test('Register and login with newly created user', async ({ page }) => {
  const user = getRegisterUser();  // generate user once

  const registerPage = new RegisterPage(page);
  await registerPage.goto();
  await registerPage.registerUser(user);

  // Confirm navigation to login page after registration
  await expect(page).toHaveURL('https://practicesoftwaretesting.com/auth/login');

  const loginPage = new LoginPage(page);
  await loginPage.goto();
  await loginPage.login(user.email, user.password);

  // Verify login success - change selector or text accordingly
  await expect(page.locator('h1')).toHaveText('My account');
});
