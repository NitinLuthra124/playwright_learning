export class CheckoutPage {
  constructor(page) {
    this.page = page;
    this.nameInput = page.locator('#name');
    this.addressInput = page.locator('#address');
    this.cityInput = page.locator('#city');
    this.submitButton = page.locator('button:has-text("Place Order")');
    this.successMessage = page.locator('.confirmation-message');
  }

  async fillShippingDetails(user) {
    await this.nameInput.fill(user.name || 'John Doe');
    await this.addressInput.fill(user.address || '123 Main St');
    await this.cityInput.fill(user.city || 'Testville');
  }

  async submitOrder() {
    await this.submitButton.click();
  }
}