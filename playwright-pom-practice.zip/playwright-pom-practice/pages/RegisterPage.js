class RegisterPage {
  /**
   * @param {import('@playwright/test').Page} page
   */
  constructor(page) {
    this.page = page;
    this.signInLink = page.locator('a:has-text("Sign In")');
    this.registerAccountLink = page.locator('a:has-text("Register your account")');
    this.firstnameInput = page.locator('#first_name');
    this.lastnameInput = page.locator('#last_name');
    this.emailInput = page.locator('#email');
    this.passwordInput = page.locator('#password');
    this.dobInput = page.locator('#dob');
    this.streetInput = page.locator('#street');
    this.PostalCodeInput = page.locator('#postal_code');
    this.CityInput = page.locator('#city');
    this.stateInput = page.locator('#state');
    this.phoneInput = page.locator('#phone');
    this.countryDropdown = page.locator('#country');
    this.registerButton = page.locator('button:has-text("Register")');
  }

  async goto() {
    await this.page.goto('https://practicesoftwaretesting.com');  
    await this.signInLink.click();
    await this.registerAccountLink.click();
  }

  async registerUser(user) {
    await this.firstnameInput.fill(user.firstName);
    await this.lastnameInput.fill(user.lastName);
    await this.emailInput.fill(user.email);
    await this.passwordInput.fill(user.password);
    await this.dobInput.fill(user.dob);
    await this.streetInput.fill(user.street);
    await this.PostalCodeInput.fill(user.postalCode);
    await this.CityInput.fill(user.city);
    await this.stateInput.fill(user.state);
    await this.phoneInput.fill(user.phone);
    await this.countryDropdown.selectOption(user.country);
    await this.registerButton.click();
  }
}

module.exports = { RegisterPage };
