export class CartPage {
  constructor(page) {
    this.page = page;
    this.checkoutButton = page.locator('button:has-text("Checkout")');
  }

  async checkout() {
    await this.checkoutButton.click();
  }
}