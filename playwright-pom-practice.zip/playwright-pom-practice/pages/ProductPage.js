export class ProductPage {
  constructor(page) {
    this.page = page;
    // Selector for product title "Pliers"
    this.productTitle = page.locator('h5[data-test="product-name"]:has-text("Pliers")');
  }

  async addPliersToCart() {
    // Wait for product title to be visible
    await this.productTitle.waitFor({ state: 'visible' });

    // Click on the product title to navigate to the product detail page
    await this.productTitle.click();

    // Wait for "Add to Cart" button on product detail page
    const addToCartButton = this.page.locator('button:has-text("Add to Cart")');
    await addToCartButton.waitFor({ state: 'visible' });

    // Click "Add to Cart"
    await addToCartButton.click();
  }

  async gotoCheckout() {
    await this.page.goto('/checkout');
  }
}
